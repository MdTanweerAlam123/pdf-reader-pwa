const fileInput = document.getElementById("file-input");
const pdfRender = document.getElementById("pdf-render");
const readAloudBtn = document.getElementById("read-aloud");

let pdfDoc = null;
let currentPage = 1;

fileInput.addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (file && file.type === "application/pdf") {
    const fileReader = new FileReader();
    fileReader.onload = function () {
      const typedarray = new Uint8Array(this.result);

      pdfjsLib.getDocument(typedarray).promise.then((pdf) => {
        pdfDoc = pdf;
        renderPage(currentPage);
      });
    };
    fileReader.readAsArrayBuffer(file);
  }
});

function renderPage(pageNumber) {
  pdfDoc.getPage(pageNumber).then((page) => {
    const viewport = page.getViewport({ scale: 1.5 });
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    canvas.height = viewport.height;
    canvas.width = viewport.width;

    const renderContext = {
      canvasContext: ctx,
      viewport: viewport,
    };

    page.render(renderContext).promise.then(() => {
      pdfRender.innerHTML = "";
      pdfRender.appendChild(canvas);
    });
  });
}

readAloudBtn.addEventListener("click", () => {
  const text = "Reading the PDF aloud is not fully implemented yet.";
  const utterance = new SpeechSynthesisUtterance(text);
  speechSynthesis.speak(utterance);
});
